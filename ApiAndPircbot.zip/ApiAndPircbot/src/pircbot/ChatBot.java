package pircbot;

public class ChatBot {
	
	//Declare webchat and the channel to use
	private static final String CONNECTION_URL = "irc.freenode.net";
	private static final String CHANNEL = "#ApiAndPircbot1";

	//Connect and join the channel using the bot
	public static void main(String[] args) {
		MyBot bot = new MyBot();
		try {
			bot.setVerbose(true);
			bot.connect(CONNECTION_URL);
			bot.joinChannel(CHANNEL);
			
			sendInitialMessage(bot);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	//Send the initial help messages
	private static void sendInitialMessage(MyBot bot) {
		bot.sendMessage(CHANNEL, "Hello There!");
		bot.sendMessage(CHANNEL, "Here are some commands you can give me:");
		bot.sendMessage(CHANNEL, "Show me weather for <city/zip> please!");
		bot.sendMessage(CHANNEL, "Show me informations about <country> please!");
	}
}
