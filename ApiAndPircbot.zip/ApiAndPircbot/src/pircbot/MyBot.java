package pircbot;

import java.util.List;

import org.jibble.pircbot.PircBot;

import api.CountriesApi;
import api.WeatherApi;

public class MyBot extends PircBot{
	
	//Initialize all the inputs used on the bot
	private static final String BOT_NAME = "OptimusPrime";
	private static final String HELLO_KEYWORD = "hello";
	private static final String WEATHER_KEYWORD = "weather";
	private static final String INFORMATION_KEYWORD = "information";
	private static final String INFORMATIONS_KEYWORD = "informations";
	private static final String PLEASE_KEYWORD = "please";
	private static final String FOR_KEYWORD = "for";
	private static final String ABOUT_KEYWORD = "about";
	private static final String HELP_KEYWORD = "help";

	//Set a name for the bot
	public MyBot() {
		this.setName(BOT_NAME);
	}
	
	//Provide the help instructions and other basic messages for the user
	@Override
	protected void onMessage(String channel, String sender, String login, String hostname, String message) {
		
		if(message.contains(HELLO_KEYWORD)) {
			sendMessage(channel, "Hi there, handsome!");
		}else if(message.contains(WEATHER_KEYWORD)){
			if(message.contains(PLEASE_KEYWORD)) {
				if(message.contains(FOR_KEYWORD)) {
					String parameter = getParameterFromMessage(message, FOR_KEYWORD);
					
					Boolean isKeywordZipCode = true;
					try {
						Integer.parseInt(parameter);
					}catch(Exception ex) {
						isKeywordZipCode = false;
					}
					
					WeatherApi weatherApi = new WeatherApi();
					String weatherInfo = null;
					if(isKeywordZipCode) {
						Integer zipCode = Integer.parseInt(parameter);
						weatherInfo = weatherApi.getWeather(zipCode);
					}else {
						weatherInfo = weatherApi.getWeather(parameter);
					}
					
					sendMessage(channel, weatherInfo);
				}else {
					sendMessage(channel, "Invalid command! Type 'help' for list of commands!");
				}
			}else {
				sendMessage(channel, "You forgot to say please!!");
			}
		}else if(message.contains(INFORMATIONS_KEYWORD) || message.contains(INFORMATION_KEYWORD)) {
			if(message.contains(PLEASE_KEYWORD)) {
				if(message.contains(ABOUT_KEYWORD)) {
					String country = getParameterFromMessage(message, ABOUT_KEYWORD);
					
					CountriesApi countriesApi = new CountriesApi();
					List<String> responseList = countriesApi.getCountryInformation(country);
					responseList.forEach((response) -> { sendMessage(channel, response);});
				}else {
					sendMessage(channel, "Invalid command! Type 'help' for list of commands!");
				}
			}else {
				sendMessage(channel, "You forgot to say please!!");
			}
		}else if(message.contains(HELP_KEYWORD)){
			sendMessage(channel, "Here are some commands you can give me:");
			sendMessage(channel, "Show me weather for <city/zip> please!");
			sendMessage(channel, "Show me informations about <country> please!");
		}else {
			sendMessage(channel, "Invalid command! Type 'help' for list of commands!");
		}
	}
	
	//Get a parameter from a message
	private String getParameterFromMessage(String message, String keyword) {
		String[] messageParts = message.split(" ");
		int index = 0;
		for(int i=0; i<messageParts.length; i++) {
			if(messageParts[i].equals(keyword)) {
				index = i;
			}
		}
		
		return messageParts[index + 1];
	}
}
